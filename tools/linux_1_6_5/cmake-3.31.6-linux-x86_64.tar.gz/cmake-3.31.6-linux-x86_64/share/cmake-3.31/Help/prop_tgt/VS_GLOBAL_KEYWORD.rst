VS_GLOBAL_KEYWORD
-----------------

Visual Studio project keyword.

Sets the "keyword" attribute for a generated Visual Studio project.
Defaults to "Win32Proj".  You may wish to override this value with
"ManagedCProj", for example, in a Visual Studio managed C++ unit test
project.
