---
name: Feature request
about: Suggest an idea for this project.
labels: enhancement
---

<!-- Describe the feature you'd like. -->
