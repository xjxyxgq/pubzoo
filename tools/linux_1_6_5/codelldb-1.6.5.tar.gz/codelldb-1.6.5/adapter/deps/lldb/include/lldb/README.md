API headers from LLDB 6.0 (commit:d359f2096850)
