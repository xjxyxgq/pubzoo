#include <cstdio>

extern "C"
void denorm_path() {
    printf("denorm_path\n"); // #BP1
}
