#include <cstdio>

extern "C"
void relative_path() {
    printf("relative_path\n"); // #BP1
}
