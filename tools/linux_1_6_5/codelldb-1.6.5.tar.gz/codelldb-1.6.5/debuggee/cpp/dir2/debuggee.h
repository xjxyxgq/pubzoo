#include <cstdio>

inline int header_fn2(int x) {
    printf("header_fn2(%d)\n", x);
    return x + 2;
}
