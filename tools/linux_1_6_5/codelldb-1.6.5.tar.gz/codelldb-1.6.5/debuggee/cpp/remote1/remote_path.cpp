#include <cstdio>

extern "C"
void remote_path1() {
    printf("remote_path1\n"); // #BP1
}
