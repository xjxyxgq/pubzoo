#include <cstdio>

extern "C"
void remote_path2() {
    printf("remote_path2\n"); // #BP1
}
