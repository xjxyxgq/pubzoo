#include <cstdio>

extern "C"
void disassembly1() {
    printf("disassembly1\n");
}
