#[test]
fn test1() {
    println!("test1");
}

#[test]
fn test2() {
    println!("test2");
}
