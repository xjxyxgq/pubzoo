from flask import Flask, jsonify, make_response
import subprocess
import sys

app = Flask(__name__)

@app.route('/run-script/<script_name>', methods=['GET'])
def run_script(script_name):
    try:
        # 设置允许运行的脚本白名单
        allowed_scripts = {
            'analyze_cluster': 'tools/analyze_cluster_usage.py',
            'generate_data': 'tools/data_gen.py'
        }
        
        if script_name not in allowed_scripts:
            return make_response(jsonify({
                'status': 'error',
                'message': 'Script not allowed',
                'data': None
            }), 403)
            
        # 运行指定的Python脚本
        result = subprocess.run([sys.executable, allowed_scripts[script_name]], 
                              capture_output=True,
                              text=True)
        
        if result.returncode == 0:
            return jsonify({
                'status': 'success',
                'message': 'Script executed successfully',
                'data': {
                    'output': result.stdout,
                    'error': result.stderr
                }
            })
        else:
            return make_response(jsonify({
                'status': 'error',
                'message': 'Script execution failed',
                'data': {
                    'output': result.stdout,
                    'error': result.stderr
                }
            }), 500)
        
    except Exception as e:
        return make_response(jsonify({
            'status': 'error',
            'message': str(e),
            'data': None
        }), 500)

# 添加CORS支持
@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    return response

if __name__ == '__main__':
    app.run(host='localhost', port=5000) 