#!/bin/bash

# 脚本功能：提交当前代码，创建新tag并推送到GitHub

# 显示帮助信息的函数
show_help() {
    echo "用法: $0 [选项]"
    echo "选项:"
    echo "  -m, --message    提交信息 (必需)"
    echo "  -t, --tag        标签名称 (可选，默认自动生成，格式为 vx.y.z)"
    echo "  -d, --desc       标签描述 (可选)"
    echo "  -M, --major      递增主版本号 (可选)"
    echo "  -N, --minor      递增次版本号 (可选，默认)"
    echo "  -P, --patch      递增修订版本号 (可选)"
    echo "  -h, --help       显示帮助信息"
    echo ""
    echo "示例: $0 -m \"修复了某个bug\" -P"
    echo "      $0 -m \"添加了新功能\" -N"
    echo "      $0 -m \"重大更新\" -M"
    echo "      $0 -m \"自定义标签\" -t \"v2.0.0\" -d \"版本2.0.0发布\""
}

# 初始化变量
COMMIT_MESSAGE=""
TAG_NAME=""
TAG_DESC=""
INCREMENT_MAJOR=false
INCREMENT_MINOR=false
INCREMENT_PATCH=false

# 解析命令行参数
while [[ $# -gt 0 ]]; do
    case $1 in
        -m|--message)
            COMMIT_MESSAGE="$2"
            shift 2
            ;;
        -t|--tag)
            TAG_NAME="$2"
            shift 2
            ;;
        -d|--desc)
            TAG_DESC="$2"
            shift 2
            ;;
        -M|--major)
            INCREMENT_MAJOR=true
            shift
            ;;
        -N|--minor)
            INCREMENT_MINOR=true
            shift
            ;;
        -P|--patch)
            INCREMENT_PATCH=true
            shift
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            echo "错误: 未知选项 $1"
            show_help
            exit 1
            ;;
    esac
done

# 检查必需参数
if [[ -z "$COMMIT_MESSAGE" ]]; then
    echo "错误: 缺少提交信息，请使用 -m 或 --message 选项"
    show_help
    exit 1
fi

# 检查是否在git仓库中
if ! git rev-parse --is-inside-work-tree &>/dev/null; then
    echo "错误: 当前目录不是git仓库"
    exit 1
fi

# 如果没有指定版本递增类型，默认递增次版本号
if [[ "$INCREMENT_MAJOR" == "false" && "$INCREMENT_MINOR" == "false" && "$INCREMENT_PATCH" == "false" ]]; then
    INCREMENT_MINOR=true
fi

# 如果没有指定标签名称，自动生成
if [[ -z "$TAG_NAME" ]]; then
    # 获取最新的标签
    LATEST_TAG=$(git tag -l | grep -E '^v[0-9]+\.[0-9]+\.[0-9]+$' | sort -V | tail -n 1)
    
    # 如果没有找到符合格式的标签，从v0.0.0开始
    if [[ -z "$LATEST_TAG" ]]; then
        LATEST_TAG="v0.0.0"
    fi
    
    # 解析版本号（去掉v前缀）
    MAJOR=$(echo $LATEST_TAG | sed 's/^v//' | cut -d. -f1)
    MINOR=$(echo $LATEST_TAG | sed 's/^v//' | cut -d. -f2)
    PATCH=$(echo $LATEST_TAG | sed 's/^v//' | cut -d. -f3)
    
    # 根据指定的递增类型更新版本号
    if [[ "$INCREMENT_MAJOR" == "true" ]]; then
        MAJOR=$((MAJOR + 1))
        MINOR=0
        PATCH=0
    elif [[ "$INCREMENT_MINOR" == "true" ]]; then
        MINOR=$((MINOR + 1))
        PATCH=0
    elif [[ "$INCREMENT_PATCH" == "true" ]]; then
        PATCH=$((PATCH + 1))
    fi
    
    # 生成新的标签名称（添加v前缀）
    TAG_NAME="v${MAJOR}.${MINOR}.${PATCH}"
    
    echo "自动生成标签: $TAG_NAME"
fi

# 确保标签名称以v开头
if [[ ! "$TAG_NAME" =~ ^v ]]; then
    TAG_NAME="v$TAG_NAME"
    echo "已将标签名称调整为: $TAG_NAME"
fi

# 如果没有提供标签描述，使用提交信息作为标签描述
if [[ -z "$TAG_DESC" ]]; then
    TAG_DESC="$COMMIT_MESSAGE"
fi

# 检查是否有修改需要提交（包括未暂存的更改和未跟踪的文件）
HAS_CHANGES=false

# 检查是否有未暂存的更改
if ! git diff --quiet; then
    HAS_CHANGES=true
fi

# 检查是否有已暂存但未提交的更改
if ! git diff --cached --quiet; then
    HAS_CHANGES=true
fi

# 检查是否有未跟踪的文件
if [ -n "$(git ls-files --others --exclude-standard)" ]; then
    HAS_CHANGES=true
fi

if [[ "$HAS_CHANGES" == "false" ]]; then
    echo "没有修改需要提交"
    
    # 询问用户是否仍要创建标签
    read -p "没有修改需要提交，是否仍要创建标签? (y/n): " CREATE_TAG
    if [[ "$CREATE_TAG" != "y" && "$CREATE_TAG" != "Y" ]]; then
        echo "操作已取消"
        exit 0
    fi
else
    # 添加所有修改
    echo "添加所有修改..."
    git add .
    
    # 提交修改
    echo "提交修改..."
    git commit -m "$COMMIT_MESSAGE"
    
    if [ $? -ne 0 ]; then
        echo "错误: 提交失败"
        exit 1
    fi
    
    echo "提交成功!"
fi

# 检查标签是否已存在
if git tag | grep -q "^$TAG_NAME$"; then
    echo "错误: 标签 '$TAG_NAME' 已存在"
    exit 1
fi

# 创建标签
echo "创建标签 '$TAG_NAME'..."
git tag -a "$TAG_NAME" -m "$TAG_DESC"

if [ $? -ne 0 ]; then
    echo "错误: 创建标签失败"
    exit 1
fi

# 推送提交和标签到远程仓库
echo "推送提交和标签到远程仓库..."
git push && git push origin "$TAG_NAME"

if [ $? -ne 0 ]; then
    echo "错误: 推送失败"
    exit 1
fi

echo "成功! 代码已提交，标签 '$TAG_NAME' 已创建并推送到远程仓库。" 