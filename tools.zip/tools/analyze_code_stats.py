# -*- coding: utf-8 -*-
import os
import re
from collections import defaultdict
from typing import Dict, Tuple

class CodeAnalyzer:
    def __init__(self):
        # 定义不同语言的文件扩展名
        self.language_extensions = {
            'go': ['.go'],
            'python': ['.py'],
            'c': ['.c', '.h'],
            'cpp': ['.cpp', '.hpp', '.cc'],
            'java': ['.java'],
            'javascript': ['.js', '.jsx']
        }
        
        # 定义不同语言的注释语法
        self.comment_patterns = {
            'single_line': {
                'go': '//',
                'python': '#',
                'c': '//',
                'cpp': '//',
                'java': '//',
                'javascript': '//'
            },
            'multi_line': {
                'go': [r'/\*', r'\*/'],
                'python': [r'"""', r'"""', r"'''", r"'''"],
                'c': [r'/\*', r'\*/'],
                'cpp': [r'/\*', r'\*/'],
                'java': [r'/\*', r'\*/'],
                'javascript': [r'/\*', r'\*/']
            }
        }

    def get_language(self, file_path: str) -> str:
        ext = os.path.splitext(file_path)[1].lower()
        for lang, extensions in self.language_extensions.items():
            if ext in extensions:
                return lang
        return None

    def analyze_file(self, file_path: str) -> Tuple[int, int, int]:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
        except UnicodeDecodeError:
            try:
                with open(file_path, 'r', encoding='latin-1') as f:
                    content = f.read()
            except:
                return 0, 0, 0

        language = self.get_language(file_path)
        if not language:
            return 0, 0, 0

        lines = content.split('\n')
        total_lines = len(lines)
        blank_lines = sum(1 for line in lines if not line.strip())
        
        # 移除多行注释
        content_without_multiline = content
        if language in self.comment_patterns['multi_line']:
            patterns = self.comment_patterns['multi_line'][language]
            for i in range(0, len(patterns), 2):
                start_pattern = patterns[i]
                end_pattern = patterns[i + 1]
                content_without_multiline = re.sub(
                    f'{start_pattern}.*?{end_pattern}',
                    '',
                    content_without_multiline,
                    flags=re.DOTALL
                )

        # 计算单行注释
        lines_without_multiline = content_without_multiline.split('\n')
        single_line_pattern = self.comment_patterns['single_line'][language]
        comment_lines = sum(1 for line in lines_without_multiline 
                          if line.strip().startswith(single_line_pattern))

        # 计算有效代码行数
        code_lines = total_lines - blank_lines - comment_lines

        return total_lines, blank_lines + comment_lines, code_lines

    def analyze_directory(self, directory: str) -> Dict[str, Dict[str, int]]:
        stats = defaultdict(lambda: {'total': 0, 'comments_and_blanks': 0, 'code': 0})
        
        for root, _, files in os.walk(directory):
            for file in files:
                file_path = os.path.join(root, file)
                language = self.get_language(file_path)
                
                if language:
                    total, comments_blanks, code = self.analyze_file(file_path)
                    stats[language]['total'] += total
                    stats[language]['comments_and_blanks'] += comments_blanks
                    stats[language]['code'] += code
                    
        return stats

def main():
    analyzer = CodeAnalyzer()
    repos_dir = 'downloaded_repos'
    
    print("开始分析代码统计信息...")
    print("-" * 60)
    
    total_stats = analyzer.analyze_directory(repos_dir)
    
    print(f"{'语言':<12} {'总行数':<10} {'注释和空行':<12} {'代码行数':<10}")
    print("-" * 60)
    
    for language, stats in total_stats.items():
        print(f"{language:<12} {stats['total']:<10} {stats['comments_and_blanks']:<12} {stats['code']:<10}")
    
    print("-" * 60)
    total_all = sum(stats['total'] for stats in total_stats.values())
    total_comments = sum(stats['comments_and_blanks'] for stats in total_stats.values())
    total_code = sum(stats['code'] for stats in total_stats.values())
    
    print(f"{'总计':<12} {total_all:<10} {total_comments:<12} {total_code:<10}")

if __name__ == '__main__':
    main() 