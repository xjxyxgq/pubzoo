#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import concurrent.futures
import ipaddress
import os
import platform
import subprocess
import time
from typing import List, Dict, Tuple, Set

import pandas as pd
from tqdm import tqdm

class IPScanner:
    def __init__(self, prefixes: List[str], timeout: float = 0.5, max_workers: int = 50):
        """
        初始化IP扫描器
        
        Args:
            prefixes: IP网段前缀列表，如 ["10.4.20", "10.20.20"]
            timeout: ping超时时间（秒）
            max_workers: 最大并发工作线程数
        """
        self.prefixes = prefixes
        self.timeout = timeout
        self.max_workers = max_workers
        self.is_windows = platform.system().lower() == "windows"
        
    def ping(self, ip: str) -> bool:
        """
        Ping指定IP地址，判断是否可达
        
        Args:
            ip: 要ping的IP地址
            
        Returns:
            bool: 如果IP可达返回True，否则返回False
        """
        if self.is_windows:
            # Windows系统使用-w参数设置超时（毫秒）
            command = ["ping", "-n", "1", "-w", str(int(self.timeout * 1000)), ip]
        else:
            # 类Unix系统使用-W参数设置超时（秒）
            command = ["ping", "-c", "1", "-W", str(int(self.timeout)), ip]
        
        try:
            result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=self.timeout + 0.5)
            return result.returncode == 0
        except subprocess.TimeoutExpired:
            return False
        except Exception:
            return False
    
    def scan_prefix(self, prefix: str) -> Tuple[str, List[str]]:
        """
        扫描指定前缀的所有IP地址
        
        Args:
            prefix: IP前缀，如 "10.4.20"
            
        Returns:
            Tuple[str, List[str]]: 包含前缀和不可达IP列表的元组
        """
        network = f"{prefix}.0/24"
        ip_list = [str(ip) for ip in ipaddress.IPv4Network(network).hosts()]
        unavailable_ips = []
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_ip = {executor.submit(self.ping, ip): ip for ip in ip_list}
            
            for future in tqdm(concurrent.futures.as_completed(future_to_ip), 
                              total=len(future_to_ip), 
                              desc=f"扫描 {prefix}",
                              leave=False):
                ip = future_to_ip[future]
                try:
                    is_available = future.result()
                    if not is_available:
                        unavailable_ips.append(ip)
                except Exception:
                    unavailable_ips.append(ip)
        
        return prefix, unavailable_ips
    
    def find_continuous_ranges(self, ip_list: List[str]) -> List[str]:
        """
        从IP列表中找出连续的IP段
        
        Args:
            ip_list: IP地址列表
            
        Returns:
            List[str]: 连续IP段的列表，格式如 "10.4.20.1-10.4.20.5"
        """
        if not ip_list:
            return []
        
        # 将IP地址转换为整数进行排序
        ip_ints = sorted([int(ipaddress.IPv4Address(ip)) for ip in ip_list])
        
        ranges = []
        range_start = ip_ints[0]
        prev_ip = ip_ints[0]
        
        for ip_int in ip_ints[1:]:
            if ip_int != prev_ip + 1:
                # 如果不连续，结束当前范围并开始新范围
                if range_start == prev_ip:
                    ranges.append(str(ipaddress.IPv4Address(range_start)))
                else:
                    ranges.append(f"{ipaddress.IPv4Address(range_start)}-{ipaddress.IPv4Address(prev_ip)}")
                range_start = ip_int
            prev_ip = ip_int
        
        # 添加最后一个范围
        if range_start == prev_ip:
            ranges.append(str(ipaddress.IPv4Address(range_start)))
        else:
            ranges.append(f"{ipaddress.IPv4Address(range_start)}-{ipaddress.IPv4Address(prev_ip)}")
        
        return ranges
    
    def scan_all(self) -> Dict[str, List[str]]:
        """
        扫描所有前缀的IP地址
        
        Returns:
            Dict[str, List[str]]: 以前缀为键，不可达IP列表为值的字典
        """
        results = {}
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=min(len(self.prefixes), 5)) as executor:
            future_to_prefix = {executor.submit(self.scan_prefix, prefix): prefix for prefix in self.prefixes}
            
            for future in tqdm(concurrent.futures.as_completed(future_to_prefix), 
                              total=len(future_to_prefix), 
                              desc="总进度"):
                prefix = future_to_prefix[future]
                try:
                    _, unavailable_ips = future.result()
                    results[prefix] = unavailable_ips
                except Exception as e:
                    print(f"扫描 {prefix} 时出错: {e}")
                    results[prefix] = []
        
        return results
    
    def export_to_excel(self, results: Dict[str, List[str]], output_file: str = "available_ips.xlsx"):
        """
        将结果导出到Excel文件
        
        Args:
            results: 扫描结果，以前缀为键，不可达IP列表为值的字典
            output_file: 输出Excel文件路径
        """
        # 创建一个Excel写入器
        with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
            # 第一个sheet：具体IP列表
            max_ips = max(len(ips) for ips in results.values()) if results else 0
            data = {}
            
            for prefix, ips in results.items():
                data[prefix] = pd.Series(ips + [''] * (max_ips - len(ips)))
            
            df = pd.DataFrame(data)
            df.to_excel(writer, sheet_name='未使用IP列表', index=False)
            
            # 第二个sheet：IP段列表
            max_ranges = 0
            ranges_data = {}
            all_ranges_by_prefix = {}
            
            for prefix, ips in results.items():
                ip_ranges = self.find_continuous_ranges(ips)
                all_ranges_by_prefix[prefix] = ip_ranges
                ranges_data[prefix] = pd.Series(ip_ranges + [''] * (max(max_ranges, len(ip_ranges)) - len(ip_ranges)))
                max_ranges = max(max_ranges, len(ip_ranges))
            
            ranges_df = pd.DataFrame(ranges_data)
            ranges_df.to_excel(writer, sheet_name='未使用IP段', index=False)
            
            # 第三个sheet：按相同连续IP段模式分类
            # 创建一个字典，键是连续IP段的模式，值是包含该模式的网段列表
            pattern_to_prefixes = {}
            
            for prefix, ip_ranges in all_ranges_by_prefix.items():
                for ip_range in ip_ranges:
                    # 提取IP段的模式（例如：从10.4.20.1-10.4.20.5提取1-5）
                    pattern = self._extract_ip_pattern(ip_range, prefix)
                    
                    if pattern not in pattern_to_prefixes:
                        pattern_to_prefixes[pattern] = {'prefixes': [], 'full_ranges': []}
                    
                    pattern_to_prefixes[pattern]['prefixes'].append(prefix)
                    pattern_to_prefixes[pattern]['full_ranges'].append(ip_range)
            
            # 创建分类表格数据
            classified_data = []
            
            for pattern, info in pattern_to_prefixes.items():
                prefixes = sorted(set(info['prefixes']))  # 去重并排序
                row = {
                    'IP段模式': pattern,
                    '网段数量': len(prefixes),
                    '网段列表': ', '.join(prefixes),
                    '示例': info['full_ranges'][0] if info['full_ranges'] else ''
                }
                classified_data.append(row)
            
            # 按网段数量降序排序
            classified_data.sort(key=lambda x: (x['网段数量'], x['IP段模式']), reverse=True)
            
            # 创建DataFrame并导出
            classified_df = pd.DataFrame(classified_data)
            classified_df.to_excel(writer, sheet_name='IP段分类', index=False)
            
            # 第四个sheet：按网段分组的连续IP段
            # 创建一个新的数据结构，按照相同的连续IP段模式分组
            grouped_data = {}
            
            # 对于每个模式，创建一行数据
            for pattern, info in pattern_to_prefixes.items():
                if len(info['prefixes']) > 1:  # 只关注出现在多个网段中的模式
                    row = {}
                    for prefix in sorted(all_ranges_by_prefix.keys()):
                        if prefix in info['prefixes']:
                            # 找到该前缀下匹配此模式的所有IP段
                            matching_ranges = [r for r in all_ranges_by_prefix[prefix] 
                                              if self._extract_ip_pattern(r, prefix) == pattern]
                            row[prefix] = ', '.join(matching_ranges)
                        else:
                            row[prefix] = ''
                    
                    grouped_data[pattern] = row
            
            # 创建DataFrame
            if grouped_data:
                grouped_df = pd.DataFrame.from_dict(grouped_data, orient='index')
                grouped_df.index.name = 'IP段模式'
                grouped_df.to_excel(writer, sheet_name='网段IP段对照表')
        
        print(f"结果已保存到 {output_file}")
    
    def _extract_ip_pattern(self, ip_range: str, prefix: str) -> str:
        """
        从IP段中提取模式
        
        Args:
            ip_range: IP段，如 "10.4.20.1-10.4.20.5"
            prefix: IP前缀，如 "10.4.20"
            
        Returns:
            str: IP段模式，如 "1-5"
        """
        # 处理单个IP的情况
        if '-' not in ip_range:
            # 提取最后一个字节
            last_byte = ip_range.split('.')[-1]
            return last_byte
        
        # 处理IP范围的情况
        start_ip, end_ip = ip_range.split('-')
        
        # 提取起始IP和结束IP的最后一个字节
        start_last_byte = start_ip.split('.')[-1]
        end_last_byte = end_ip.split('.')[-1]
        
        return f"{start_last_byte}-{end_last_byte}"

def main():
    parser = argparse.ArgumentParser(description='扫描多个网段中的未使用IP地址')
    parser.add_argument('prefixes', nargs='+', help='IP网段前缀列表，如 10.4.20 10.20.20')
    parser.add_argument('--timeout', type=float, default=0.5, help='ping超时时间（秒），默认0.5秒')
    parser.add_argument('--max-workers', type=int, default=50, help='最大并发工作线程数，默认50')
    parser.add_argument('--output', type=str, default='available_ips.xlsx', help='输出Excel文件路径')
    
    args = parser.parse_args()
    
    print(f"开始扫描以下网段: {', '.join(args.prefixes)}")
    scanner = IPScanner(args.prefixes, args.timeout, args.max_workers)
    results = scanner.scan_all()
    scanner.export_to_excel(results, args.output)

if __name__ == "__main__":
    main() 