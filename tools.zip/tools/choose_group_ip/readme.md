# IP可用性检测工具

这个工具用于检测多个网段中哪些IP地址是不可达的（未被使用），并将结果输出到Excel文件中。

## 功能特点

- 支持同时检测多个网段的IP地址
- 使用并发方式加快检测速度
- 将结果导出到Excel文件，包含两个工作表：
  - 第一个工作表：按网段列出所有未使用的具体IP地址
  - 第二个工作表：按网段列出未使用的连续IP段

## 依赖项

使用前需要安装以下Python包：

```bash
pip install pandas>=1.3.0 openpyxl>=3.0.7 tqdm>=4.61.0
```

或者使用requirements.txt安装：

```bash
pip install -r requirements.txt
```

## 使用方法

### 基本用法

```bash
python find_available_ips.py 10.4.20 10.20.20 10.36.20
```

这将检测三个网段（10.4.20.0/24、10.20.20.0/24和10.36.20.0/24）中的所有IP地址，并将结果保存到默认的`available_ips.xlsx`文件中。

### 高级选项

```bash
python find_available_ips.py 10.4.20 10.20.20 --timeout 1.0 --max-workers 100 --output my_results.xlsx
```

参数说明：
- `--timeout`：ping超时时间（秒），默认为0.5秒
- `--max-workers`：最大并发工作线程数，默认为50
- `--output`：输出Excel文件路径，默认为`available_ips.xlsx`

## 输出说明

输出的Excel文件包含两个工作表：

1. **未使用IP列表**：每列对应一个网段，列出该网段中所有不可达（未使用）的IP地址
2. **未使用IP段**：每列对应一个网段，列出该网段中不可达（未使用）的连续IP段，格式如`10.4.20.1-10.4.20.5`

## 注意事项

- 检测速度取决于网络状况和并发数量
- 对于大型网络，可能需要较长时间完成扫描
- 某些网络环境可能会限制ping请求，影响检测结果
- 脚本默认扫描每个网段的整个/24子网（即256个IP地址）