#! /opt/anaconda3/envs/cmpool/bin/python3
# -*- coding: utf-8 -*-
import pandas as pd
import mysql.connector
from collections import defaultdict
import os

# 确保安装了openpyxl
try:
    import openpyxl
except ImportError:
    print("请先安装 openpyxl: pip install openpyxl")
    exit(1)

# 数据库连接配置
db_config = {
    'host': '127.0.0.1',
    'port': 3311,
    'user': 'root',
    'password': 'nov24feb11',
    'database': 'cmpool'
}

def get_cluster_ips():
    """从MySQL获取集群和IP的对应关系"""
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()
        
        cursor.execute("SELECT cluster_name, ip FROM cluster_ips")
        cluster_ip_map = defaultdict(list)
        for cluster_name, ip in cursor.fetchall():
            cluster_ip_map[cluster_name].append(ip)
            
        return cluster_ip_map
        
    except mysql.connector.Error as err:
        print(f"数据库错误: {err}")
        return None
    finally:
        if 'conn' in locals() and conn.is_connected():
            cursor.close()
            conn.close()

def read_data_file(file_path):
    """Read data from either xlsx or csv file"""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")
    
    file_ext = os.path.splitext(file_path)[1].lower()
    
    try:
        if file_ext == '.xlsx':
            return pd.read_excel(file_path, engine='openpyxl')
        elif file_ext == '.csv':
            return pd.read_csv(file_path)
        else:
            raise ValueError(f"Unsupported file format: {file_ext}. Please use .xlsx or .csv")
    except Exception as e:
        raise Exception(f"Error reading file {file_path}: {str(e)}")

def analyze_cluster_usage(file_path='server_data.xlsx'):
    """
    Analyze cluster resource usage from either xlsx or csv file
    
    Args:
        file_path (str): Path to the data file (.xlsx or .csv)
    """
    # Define resource utilization thresholds
    THRESHOLDS = {
        'CPU': 10,    # Maximum CPU utilization threshold
        'MEM': 20,    # Maximum memory utilization threshold
        'DISK': 20    # Maximum disk utilization threshold
    }
    
    # Read data file
    try:
        df = read_data_file(file_path)
    except Exception as e:
        print(f"Error: {e}")
        return
    
    # Verify required columns exist
    required_columns = ['IP地址', '最大CPU', '最大内存', '最大磁盘']
    missing_columns = [col for col in required_columns if col not in df.columns]
    if missing_columns:
        print(f"Error: Missing required columns: {', '.join(missing_columns)}")
        return
    
    # Get cluster-IP mapping
    cluster_ip_map = get_cluster_ips()
    if not cluster_ip_map:
        return
    
    # Analyze resource usage for each cluster
    underutilized_clusters = []
    
    for cluster_name, ips in cluster_ip_map.items():
        # Get resource usage data for all IPs in this cluster
        cluster_data = df[df['IP地址'].isin(ips)]
        
        if cluster_data.empty:
            continue
            
        # Calculate cluster-level maximum resource usage
        max_cpu = cluster_data['最大CPU'].max()
        max_mem = cluster_data['最大内存'].max()
        max_disk = cluster_data['最大磁盘'].max()
        
        # Check if resource utilization is below thresholds
        if (max_cpu < THRESHOLDS['CPU'] or 
            max_mem < THRESHOLDS['MEM'] or 
            max_disk < THRESHOLDS['DISK']):
            
            underutilized_clusters.append({
                'cluster_name': cluster_name,
                'ip_count': len(ips),
                'max_cpu': max_cpu,
                'max_mem': max_mem,
                'max_disk': max_disk
            })
    
    # Output analysis results
    if underutilized_clusters:
        # Define column widths
        COL_WIDTHS = {
            'cluster': 20,
            'ip_count': 10,
            'metrics': 12,  # width for each metric column
            'ips': 45
        }
        
        print("\nClusters with Underutilized Resources:")
        total_width = COL_WIDTHS['cluster'] + COL_WIDTHS['ip_count'] + COL_WIDTHS['metrics']*3 + COL_WIDTHS['ips']
        print("-" * total_width)
        
        # Print header
        print(f"{'Cluster Name':{COL_WIDTHS['cluster']}} "
              f"{'IP Count':{COL_WIDTHS['ip_count']}} "
              f"{'Max CPU':{COL_WIDTHS['metrics']}} "
              f"{'Max Mem':{COL_WIDTHS['metrics']}} "
              f"{'Max Disk':{COL_WIDTHS['metrics']}} "
              f"{'IPs':{COL_WIDTHS['ips']}}")
        print("-" * total_width)
        
        for cluster in underutilized_clusters:
            # Get IPs for this cluster
            cluster_ips = cluster_ip_map[cluster['cluster_name']]
            # Format IP list (show up to 5 IPs)
            ip_display = ', '.join(cluster_ips[:5])
            if len(cluster_ips) > 5:
                ip_display += '...'
                
            # Format each metric with percentage
            cpu_str = f"{cluster['max_cpu']:.2f}%"
            mem_str = f"{cluster['max_mem']:.2f}%"
            disk_str = f"{cluster['max_disk']:.2f}%"
            
            print(f"{cluster['cluster_name']:{COL_WIDTHS['cluster']}} "
                  f"{cluster['ip_count']:{COL_WIDTHS['ip_count']}} "
                  f"{cpu_str:{COL_WIDTHS['metrics']}} "
                  f"{mem_str:{COL_WIDTHS['metrics']}} "
                  f"{disk_str:{COL_WIDTHS['metrics']}} "
                  f"{ip_display:{COL_WIDTHS['ips']}}")
    else:
        print("No clusters found with underutilized resources")

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Analyze cluster resource usage from xlsx or csv file')
    parser.add_argument('--file', '-f', 
                       default='server_data.xlsx',
                       help='Path to the data file (.xlsx or .csv)')
    
    args = parser.parse_args()
    analyze_cluster_usage(args.file) 